import { Routes } from '@angular/router';
import { authGuard, branchHeadGuard, loginRedirectGuard } from './core/auth/auth.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./splash-page/splash-page').then(m => m.SplashPage),
  },
  {
    path: 'login',
    canActivate: [loginRedirectGuard],
    loadChildren: () => import('./login-page-module/login-page-module-module').then(m => m.LoginPageModuleModule),
  },
  {
    path: 'app',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/layout').then(m => m.Layout),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      { path: 'dashboard', loadComponent: () => import('./pages/dashboard/dashboard').then(m => m.Dashboard) },
      {
        path: 'call-center',
        loadComponent: () => import('./features/call-center/call-center').then(m => m.CallCenter),
        children: [
          { path: '', pathMatch: 'full', loadComponent: () => import('./features/call-center/dashboard/call-center-dashboard').then(m => m.CallCenterDashboard) },
          { path: 'history', loadComponent: () => import('./features/call-center/call-history/call-history').then(m => m.CallHistory) },
          { path: 'missed', canActivate: [branchHeadGuard], loadComponent: () => import('./features/call-center/missed-calls/missed-calls').then(m => m.MissedCalls) },
          { path: 'telecallers', canActivate: [branchHeadGuard], loadComponent: () => import('./features/call-center/telecaller-status/telecaller-status').then(m => m.TelecallerStatus) },
        ],
      },
      { path: 'lead-management', loadComponent: () => import('./pages/lead-management/lead-management').then(m => m.LeadManagement) },
      { path: 'follow-ups', loadComponent: () => import('./pages/followups/followups').then(m => m.Followups) },
      { path: 'masters/service-category', loadComponent: () => import('./pages/look-up-master/service-category/service-category').then(m => m.ServiceCategory) },
      { path: 'masters/source', loadComponent: () => import('./pages/look-up-master/source/source').then(m => m.Source) },
      { path: 'masters/lead-status', loadComponent: () => import('./pages/look-up-master/lead-status/lead-status').then(m => m.LeadStatus) },
      { path: 'masters/organization', loadComponent: () => import('./pages/look-up-master/organization/organization').then(m => m.Organization) },
      { path: 'masters/users', loadComponent: () => import('./pages/look-up-master/users/users').then(m => m.Users) },
      { path: 'masters/roles', loadComponent: () => import('./pages/look-up-master/roles/roles').then(m => m.Roles) },
      { path: 'masters/roles-and-permission', loadComponent: () => import('./pages/look-up-master/roles-permission/roles-permission').then(m => m.RolesPermission) },
      { path: 'masters/roles-and-permission/add', loadComponent: () => import('./pages/look-up-master/roles-permission/add-roles-permission-form/add-roles-permission-form').then(m => m.AddRolesPermissionForm) },
      { path: 'masters/roles-and-permission/edit/:id', loadComponent: () => import('./pages/look-up-master/roles-permission/add-roles-permission-form/add-roles-permission-form').then(m => m.AddRolesPermissionForm) },
      { path: 'masters/roles-and-permission/assign', loadComponent: () => import('./pages/look-up-master/roles-permission/role-permission-matrix/role-permission-matrix').then(m => m.RolePermissionMatrix) },
      { path: 'masters/user', loadComponent: () => import('./pages/look-up-master/users/users').then(m => m.Users) },
      { path: 'appointments', loadComponent: () => import('./pages/appointment-page/appointment-page').then(m => m.AppointmentPage) },
      { path: 'customers', loadComponent: () => import('./pages/customer-portal-page/customer-portal-page').then(m => m.CustomerPortalPage) },
      { path: 'treatments', loadComponent: () => import('./pages/treatment-management/treatment-management').then(m => m.TreatmentManagement) },
      { path: 'treatments/create', loadComponent: () => import('./pages/treatment-management/treatment-create').then(m => m.TreatmentCreate) },
      { path: 'inventory', pathMatch: 'full', redirectTo: 'inventory/products' },
      { path: 'inventory/products', loadComponent: () => import('./pages/inventory/product-management/product-management').then(m => m.ProductManagement) },
      { path: 'inventory/vendors', loadComponent: () => import('./pages/inventory/vendor-management/vendor-management').then(m => m.VendorManagement) },
      { path: 'hr-management', loadComponent: () => import('./pages/dashboard/dashboard').then(m => m.Dashboard) },
      { path: 'reports', loadComponent: () => import('./pages/reports/reports').then(m => m.Reports) },
      { path: 'reports/:id', loadComponent: () => import('./pages/reports/report-detail/report-detail').then(m => m.ReportDetail) },
      { path: 'settings', loadComponent: () => import('./pages/settings-page/settings-page').then(m => m.SettingsPage) },

    ],
  },
  {
    // Branch QR codes point here (?code=<encrypted branch code>) - logs the scan, then
    // redirects on to the configured lead form.
    path: 'scan',
    loadComponent: () => import('./public/qr-landing-page/qr-landing-page').then(m => m.QrLandingPage),
  },
  {
    // Current QR codes carry data via ?d=... on this path; :id is kept for older/manual links.
    path: 'branch-info',
    loadComponent: () => import('./public/branch-info-page/branch-info-page').then(m => m.BranchInfoPage),
  },
  {
    path: 'branch-info/:id',
    loadComponent: () => import('./public/branch-info-page/branch-info-page').then(m => m.BranchInfoPage),
  },
  { path: '404', loadComponent: () => import('./not-found-page/not-found-page').then(m => m.NotFoundPage) },
  { path: '**', loadComponent: () => import('./not-found-page/not-found-page').then(m => m.NotFoundPage) },
];
