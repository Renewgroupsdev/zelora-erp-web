import { CommonModule } from '@angular/common';
import { Component, DestroyRef, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { AuthService } from '../../../core/auth/auth.service';
import { CommonDetailCard } from '../../../shared/components/common-detail-card/common-detail-card';
import { CommonFilterCard } from '../../../shared/components/common-filter-card/common-filter-card';
import { CommonTableCard } from '../../../shared/components/common-table-card/common-table-card';
import { ModuleTabs } from '../../../shared/components/module-tabs/module-tabs';
import { DetailCardData, TableColumn, TableRow } from '../../../shared/models/common-components.model';
import { DEPARTMENTS, hoursLabel, workedHours } from '../../../shared/models/hr.model';
import { downloadExcel } from '../../../shared/utils/export.util';
import { displayDate, displayTime, isoDate, monthLabel } from '../../../shared/utils/format.util';
import { HrListBase } from '../hr-list-base';
import { AttendanceEdit } from './attendance-edit/attendance-edit';

const DAILY_COLUMNS: TableColumn[] = [
  { key: 'empCode', header: 'Emp Code', width: '8%' },
  { key: 'employee', header: 'Employee', width: '17%' },
  { key: 'department', header: 'Department', width: '11%' },
  { key: 'branch', header: 'Branch', type: 'branch', width: '11%' },
  { key: 'checkIn', header: 'Check In', width: '9%' },
  { key: 'checkOut', header: 'Check Out', width: '9%' },
  { key: 'hours', header: 'Worked', width: '8%' },
  { key: 'status', header: 'Status', type: 'badge', width: '9%' },
  { key: 'remarks', header: 'Remarks / Source', width: '12%' },
  { key: 'actions', header: 'Action', type: 'quickActions', width: '6%', sortable: false },
];

const MONTHLY_COLUMNS: TableColumn[] = [
  { key: 'empCode', header: 'Emp Code', width: '8%' },
  { key: 'employee', header: 'Employee', width: '17%' },
  { key: 'branch', header: 'Branch', type: 'branch', width: '11%' },
  { key: 'present', header: 'Present', width: '7%' },
  { key: 'late', header: 'Late', width: '7%' },
  { key: 'half', header: 'Half Day', width: '7%' },
  { key: 'absent', header: 'Absent', width: '7%' },
  { key: 'leave', header: 'Leave', width: '7%' },
  { key: 'permission', header: 'Permission', width: '8%' },
  { key: 'hours', header: 'Total Hours', width: '9%' },
  { key: 'avg', header: 'Avg / Day', width: '8%' },
];

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDialogModule, CommonDetailCard, CommonFilterCard, CommonTableCard, ModuleTabs],
  templateUrl: './attendance.html',
  styleUrls: ['../../../shared/styles/erp-page.scss', './attendance.scss'],
})
export class Attendance extends HrListBase {
  private readonly auth = inject(AuthService);
  protected readonly noun = 'records';

  readonly view = signal<'daily' | 'monthly'>('daily');
  readonly date = signal(isoDate());
  readonly month = signal(isoDate().slice(0, 7));
  readonly now = signal(new Date());
  readonly today = isoDate();
  readonly displayTime = displayTime;
  readonly displayDate = displayDate;
  readonly monthLabel = monthLabel;
  readonly hoursLabel = hoursLabel;

  /** Employee whose punch panel is shown - the signed-in user when they're on the employee list. */
  punchEmpId = this.hr.activeEmployees().find(e => e.name === this.auth.currentUser()?.name)?.id ?? this.hr.activeEmployees()[0]?.id ?? '';
  readonly punchVersion = signal(0);
  readonly punchRecord = computed(() => {
    this.punchVersion();
    this.hr.attendance();
    return this.hr.todayRecord(this.punchEmpId);
  });

  override filters = [
    { key: 'status', label: 'Status', options: ['Present', 'Late', 'Half Day', 'Absent', 'On Leave', 'Permission', 'Not Marked'] },
    { key: 'source', label: 'Department', options: DEPARTMENTS },
    { key: 'branch', label: 'Branch', options: this.hr.branches, multiSelect: true },
  ];

  columns: TableColumn[] = DAILY_COLUMNS;
  override sortActive = 'empCode';
  override sortDirection: 'asc' | 'desc' = 'asc';

  constructor() {
    super();
    const timer = setInterval(() => this.now.set(new Date()), 1000);
    inject(DestroyRef).onDestroy(() => clearInterval(timer));
  }

  readonly stats = computed<DetailCardData[]>(() => {
    const day = this.hr.attendance().filter(a => a.date === this.date());
    const count = (...s: string[]) => day.filter(a => s.includes(a.status)).length;
    const total = this.hr.activeEmployees().filter(e => e.status !== 'Onboarding').length;
    return [
      { label: `Present · ${displayDate(this.date())}`, value: `${count('Present', 'Late', 'Half Day', 'Permission')} / ${total}`, icon: 'bi-person-check-fill', iconVariant: 'green' },
      { label: 'Late Check-ins', value: count('Late'), icon: 'bi-alarm', iconVariant: 'orange' },
      { label: 'On Leave', value: count('On Leave'), icon: 'bi-calendar2-x', iconVariant: 'blue' },
      { label: 'Absent / Not Marked', value: total - count('Present', 'Late', 'Half Day', 'Permission', 'On Leave'), icon: 'bi-person-x', iconVariant: 'purple' },
    ];
  });

  setView(view: 'daily' | 'monthly'): void {
    this.view.set(view);
    this.columns = view === 'daily' ? DAILY_COLUMNS : MONTHLY_COLUMNS;
    this.currentPage = 1;
    this.refresh();
  }

  setDate(value: string): void {
    if (!value) return;
    this.date.set(value);
    this.refresh();
  }

  setMonth(value: string): void {
    if (!value) return;
    this.month.set(value);
    this.refresh();
  }

  protected allRows(): TableRow[] {
    const employees = this.hr.activeEmployees().filter(e => e.status !== 'Onboarding');
    const attendance = this.hr.attendance();

    if (this.view() === 'monthly') {
      const month = this.month();
      return employees.map(e => {
        const list = attendance.filter(a => a.empId === e.id && a.date.startsWith(month));
        const count = (s: string) => list.filter(a => a.status === s).length;
        const hours = list.reduce((s, a) => s + workedHours(a), 0);
        const days = list.filter(a => a.checkOut).length;
        return {
          id: e.id, empCode: e.empCode, employee: e.name, department: e.department, branch: e.branch,
          present: String(count('Present')), __present: count('Present'),
          late: String(count('Late')), __late: count('Late'),
          half: String(count('Half Day')), __half: count('Half Day'),
          absent: String(count('Absent')), __absent: count('Absent'),
          leave: String(count('On Leave')), __leave: count('On Leave'),
          permission: String(count('Permission')), __permission: count('Permission'),
          hours: hoursLabel(hours), __hours: Math.round(hours * 100) / 100,
          avg: hoursLabel(days ? hours / days : 0), __avg: days ? Math.round((hours / days) * 100) / 100 : 0,
          status: '',
        };
      });
    }

    const date = this.date();
    return employees.map(e => {
      const a = attendance.find(x => x.empId === e.id && x.date === date);
      const hours = a ? workedHours(a) : 0;
      return {
        id: e.id,
        empCode: e.empCode,
        employee: e.name,
        department: e.department,
        branch: e.branch,
        checkIn: displayTime(a?.checkIn), __checkIn: a?.checkIn ?? '',
        checkOut: a?.checkIn && !a.checkOut && date === this.today ? 'Working…' : displayTime(a?.checkOut), __checkOut: a?.checkOut ?? '',
        hours: hoursLabel(hours), __hours: hours,
        status: a?.status ?? 'Not Marked',
        remarks: a ? a.remarks || a.source : '-',
        actions: [{ key: 'edit', icon: 'bi-pencil-square', label: 'Regularise' }],
      };
    });
  }

  onQuickAction(event: { row: TableRow; action: string }): void {
    this.openDialog(AttendanceEdit, { empId: event.row['id'], date: this.date() }, '520px');
  }

  checkIn(): void {
    const r = this.hr.checkIn(this.punchEmpId);
    this.punchVersion.update(v => v + 1);
    Swal.fire({ toast: true, position: 'top-end', icon: r.status === 'Late' ? 'warning' : 'success', title: r.status === 'Late' ? 'Checked in (late)' : 'Checked in', text: `${this.hr.employeeName(this.punchEmpId)} at ${displayTime(r.checkIn)}`, showConfirmButton: false, timer: 3000 });
  }

  checkOut(): void {
    const r = this.hr.checkOut(this.punchEmpId);
    this.punchVersion.update(v => v + 1);
    if (r) Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Checked out', text: `Worked ${hoursLabel(workedHours(r))}`, showConfirmButton: false, timer: 3000 });
  }

  liveHours(): string {
    const r = this.punchRecord();
    if (!r?.checkIn) return '0h 00m';
    return hoursLabel(workedHours({ checkIn: r.checkIn, checkOut: r.checkOut ?? this.now().toISOString() }));
  }

  exportExcel(): void {
    const sheet = this.exportSheet(this.view() === 'daily' ? `Attendance ${this.date()}` : `Summary ${this.month()}`);
    downloadExcel(this.view() === 'daily' ? `attendance-${this.date()}` : `attendance-summary-${this.month()}`, [sheet]);
  }
}
