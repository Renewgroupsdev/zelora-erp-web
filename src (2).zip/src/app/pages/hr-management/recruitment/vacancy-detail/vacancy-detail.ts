import { CommonModule } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { HrService } from '../../../../shared/common-services/hr.service';
import { CANDIDATE_STAGES, Candidate, CandidateStage, JOB_PORTALS, JobPortal } from '../../../../shared/models/hr.model';
import { addDays, displayDate, isoDate } from '../../../../shared/utils/format.util';
import { downloadResume, exportCandidates } from '../resume';

/** One vacancy's recruitment workspace: portals, applicants, pipeline, resumes and hiring. */
@Component({
  selector: 'app-vacancy-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDialogModule],
  templateUrl: './vacancy-detail.html',
  styleUrls: ['../../../../shared/styles/erp-dialog.scss', './vacancy-detail.scss'],
})
export class VacancyDetail {
  private readonly dialogRef = inject(MatDialogRef<VacancyDetail>);
  private readonly data = inject<{ vacancyId: string }>(MAT_DIALOG_DATA);
  readonly hr = inject(HrService);

  readonly portals = JOB_PORTALS;
  readonly stages = CANDIDATE_STAGES;
  readonly displayDate = displayDate;
  readonly syncing = signal<JobPortal | null>(null);
  readonly sourceFilter = signal<string>('All');
  readonly stageFilter = signal<string>('All');

  readonly vacancy = computed(() => this.hr.manpower().find(m => m.id === this.data.vacancyId)!);
  readonly allCandidates = computed(() => this.hr.candidates().filter(c => c.vacancyId === this.data.vacancyId));
  readonly candidates = computed(() => this.allCandidates()
    .filter(c => this.sourceFilter() === 'All' || c.source === this.sourceFilter())
    .filter(c => this.stageFilter() === 'All' || c.stage === this.stageFilter())
    .sort((a, b) => b.appliedAt.localeCompare(a.appliedAt)));
  readonly pipeline = computed(() => this.stages.map(s => ({ stage: s, count: this.allCandidates().filter(c => c.stage === s).length })));
  readonly bySource = computed(() => ['Indeed', 'LinkedIn', 'Naukri', 'Referral', 'Walk-in'].map(s => ({ source: s, count: this.allCandidates().filter(c => c.source === s).length })));

  isPosted(p: JobPortal): boolean {
    return this.vacancy().postedTo.includes(p);
  }

  post(p: JobPortal): void {
    this.hr.postToPortals(this.vacancy().id, [p]);
    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: `Job posted on ${p}`, showConfirmButton: false, timer: 2500 });
  }

  sync(p: JobPortal): void {
    this.syncing.set(p);
    // Simulated portal round-trip.
    setTimeout(() => {
      const fresh = this.hr.syncApplicants(this.vacancy().id, p);
      this.syncing.set(null);
      Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: `${fresh.length} new applicant${fresh.length === 1 ? '' : 's'} from ${p}`, showConfirmButton: false, timer: 3000 });
    }, 700);
  }

  overBudget(c: Candidate): boolean {
    return c.expectedCtc > this.vacancy().budgetMax;
  }

  setStage(c: Candidate, stage: CandidateStage): void {
    if (stage === 'Hired') {
      this.hire(c);
      return;
    }
    this.hr.moveCandidate(c.id, stage);
  }

  rate(c: Candidate, rating: number): void {
    this.hr.moveCandidate(c.id, c.stage, { rating });
  }

  async scheduleInterview(c: Candidate): Promise<void> {
    const { value } = await Swal.fire({
      title: `Interview · ${c.name}`,
      input: 'text',
      inputLabel: 'Date & time',
      inputValue: `${addDays(isoDate(), 1)}T11:00`,
      didOpen: () => { const i = Swal.getInput(); if (i) i.type = 'datetime-local'; },
      showCancelButton: true,
      confirmButtonText: 'Schedule',
      confirmButtonColor: '#6C63FF',
    });
    if (value) this.hr.moveCandidate(c.id, 'Interview', { interviewAt: new Date(value).toISOString() });
  }

  async hire(c: Candidate): Promise<void> {
    const v = this.vacancy();
    const offer = Math.min(v.budgetMax, Math.max(v.budgetMin, c.expectedCtc));
    const result = await Swal.fire({
      title: `Hire ${c.name}?`,
      html: `
        <label style="display:block;text-align:left;font-size:13px;margin:6px 0 2px">Joining date</label>
        <input id="hire-date" type="date" class="swal2-input" style="margin:0;width:100%" value="${addDays(isoDate(), Math.max(7, c.noticeDays))}">
        <label style="display:block;text-align:left;font-size:13px;margin:10px 0 2px">Offered monthly gross (budget ₹${v.budgetMin.toLocaleString('en-IN')} - ₹${v.budgetMax.toLocaleString('en-IN')})</label>
        <input id="hire-ctc" type="number" class="swal2-input" style="margin:0;width:100%" value="${offer}">`,
      showCancelButton: true,
      confirmButtonText: 'Hire & start onboarding',
      confirmButtonColor: '#0f9d58',
      preConfirm: () => {
        const date = (document.getElementById('hire-date') as HTMLInputElement).value;
        const ctc = Number((document.getElementById('hire-ctc') as HTMLInputElement).value);
        if (!date || !ctc) { Swal.showValidationMessage('Enter joining date and salary'); return false; }
        return { date, ctc };
      },
    });
    if (result.isConfirmed && result.value) this.hr.hireCandidate(c.id, result.value.date, result.value.ctc);
  }

  resume(c: Candidate): void {
    downloadResume(c, this.vacancy());
  }

  exportExcel(): void {
    exportCandidates(this.candidates(), () => `${this.vacancy().designation} - ${this.vacancy().branch}`, `candidates-${this.vacancy().requestNo}`);
  }

  close(): void {
    this.dialogRef.close();
  }
}
